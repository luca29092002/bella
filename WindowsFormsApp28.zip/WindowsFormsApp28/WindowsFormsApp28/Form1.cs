﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApp28
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int i = 2;
        public int j = 1;
        private void button1_Click(object sender, EventArgs e)
        {
            TextBox lb = new TextBox();
            lb.Text = textBox1.Text;
            Point po = new Point(210,10*i);
            lb.Width = 200;
            lb.Location = po;
            panel1.Controls.Add(lb);
            if (lb.Text.ToLower().Contains("bene"))
            {
                TextBox txb = new TextBox();
                txb.Text = "sono contento per te";
                Point po2 = new Point(10,35);
                txb.Width = 120;
                txb.Location=po2;
               panel1.Controls.Add(txb);
            }
            if (lb.Text.ToLower().Contains("male"))
            {
                TextBox txb = new TextBox();
                txb.Text = "mi dispiace";
                Point po2 = new Point(10, 35);
                txb.Width = 90;
                txb.Location = po2;
                panel1.Controls.Add(txb);
            }
            lb.BackColor = Color.LawnGreen;
               textBox1.Clear();
                TextBox tx = new TextBox();
                tx.Text = "scrivere quale informazione vuoi sapere?";
                tx.Width = 200;
                Point p = new Point(10, 59*j);
                tx.Location = p;
               panel1.Controls.Add(tx);
            i=i+6;
            j++;
            if(lb.Text.ToLower().Contains("posizione"))
            {
                System.Diagnostics.Process.Start("https://www.google.com/maps/place/Disc+S.p.A./@45.6799864,9.6648004,17z/data=!3m1!4b1!4m5!3m4!1s0x478151af4e28bdcf:0x2f016868135b0b9f!8m2!3d45.6799827!4d9.6669891");
            }
            if(lb.Text.ToLower().Contains("contatti")||lb.Text.ToLower().Contains("contatto"))
            {
                System.Diagnostics.Process.Start("http://www.disc.it/SitePages/contatti.aspx");
            }
            if (lb.Text.ToLower().Contains("storia"))
            {
                System.Diagnostics.Process.Start("http://www.disc.it/SitePages/Storia.aspx");
            }
            if (lb.Text.ToLower().Contains("storia"))
            {
                System.Diagnostics.Process.Start("http://www.disc.it/SitePages/Storia.aspx");
            }
            if (lb.Text.ToLower().Contains("management"))
            {
                System.Diagnostics.Process.Start("http://www.disc.it/SitePages/Press.aspx");
            }
            if (lb.Text.ToLower().Contains("google maps"))
            {
                System.Diagnostics.Process.Start("https://www.google.com/maps/");
            }
            if (lb.Text.ToLower().Contains("google"))
            {
                System.Diagnostics.Process.Start("https://www.google.com/");
            }
            if (lb.Text.ToLower().Contains("youtube"))
            {
                System.Diagnostics.Process.Start("https://youtube.come");
            }
            if (lb.Text.ToLower().Contains("hotmail"))
            {
                System.Diagnostics.Process.Start("https://www.hotmail.com/");
            }
            if (lb.Text.ToLower().Contains("libero"))
            {
                System.Diagnostics.Process.Start("https://www.libero.it/");
            }
            if (lb.Text.ToLower().Contains("gmail"))
            {
                System.Diagnostics.Process.Start("https://www.gmail.com/");
            }
            if (lb.Text.ToLower().Contains("instagram"))
            {
                System.Diagnostics.Process.Start("https://www.instagram.com/");
            }
            if (lb.Text.ToLower().Contains("twitter"))
            {
                System.Diagnostics.Process.Start("https://www.twitter.com/");
            }
            if (lb.Text.ToLower().Contains("facebook"))
            {
                System.Diagnostics.Process.Start("https://www.facebook.com/");
            }
        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            TextBox lb = new TextBox();
            lb.Text = "ciao,come stai?";
            lb.Width = 80;
            Point po = new Point(10,5);
            lb.Location = po;
            panel1.Controls.Add(lb);
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
    }
}
